﻿using Microsoft.EntityFrameworkCore;

namespace SikkerhedsLogRepositoryLib
{
    public class SikkerhedsLogDBContext : DbContext
    {
        public SikkerhedsLogDBContext(DbContextOptions<SikkerhedsLogDBContext> options) : base(options) { }
        public DbSet<SikkerhedsLog> SikkerhedsLog { get; set; }
    }
}